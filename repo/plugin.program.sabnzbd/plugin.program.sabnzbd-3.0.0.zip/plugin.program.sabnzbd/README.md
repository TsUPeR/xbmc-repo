SABnzbd
=========
SABnzbd is an Open Source Binary Newsreader written in Python. This is the XBMC addon for managing SABnzbd.
This is a continuation of the first SABnzbd addon made by "Kricker" in the XBMC.org forum.
The code is re-written from scratch by  "Popeye".
It uses [SABnzbd](http://www.sabnzbd.org) as backbone.

API
===

SABnzbd has a set of API's for other add-on's to use.

BASE
----
plugin://plugin.program.sabnzbd/

PLAY
----
?mode=play&nzb=[url.encoded.nzb.http.path]&nzbname=[url.encoded.output.name]

DOWNLOAD
--------
?mode=download&nzb=[url.encoded.nzb.http.path]&nzbname=[url.encoded.output.name]
